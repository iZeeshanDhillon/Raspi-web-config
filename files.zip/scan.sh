sudo iwlist wlan0 scan|grep SSID > /tmp/scan.txt
