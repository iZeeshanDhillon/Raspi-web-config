username = 'zeshan'
password = '12345'
current_username = 'zeeshan'
cmd = 'usermod -l ' + username + ' ' + current_username + 
print(cmd)